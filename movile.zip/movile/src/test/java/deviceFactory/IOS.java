package deviceFactory;

import io.appium.java_client.AppiumDriver;

import java.net.MalformedURLException;

public class IOS implements IDevice{
    @Override
    public AppiumDriver create() throws MalformedURLException {
        return null;
    }
}
