package appiumControl;

import org.openqa.selenium.By;

public class Button extends Control{
    public Button(By locator) {
        super(locator);
    }
}
