package appiumControl;

import org.openqa.selenium.By;

public class Label extends Control{
    public Label(By locator) {
        super(locator);
    }
}
