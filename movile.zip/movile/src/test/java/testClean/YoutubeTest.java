package testClean;

import activity.youtube.MainActivity;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import sessionManager.Session;

import java.net.MalformedURLException;

public class YoutubeTest {

    MainActivity youtube = new MainActivity();


    @Test
    public void BuscarVideo() throws MalformedURLException {
        youtube.buttonBuscar.Click();
        youtube.textBuscar.Write("servicio rest api");
        String actualResult = youtube.textBuscar.GetText();
        String expectedResult = "servicio rest api";
        Assert.assertEquals("no add done correctly", expectedResult, actualResult);
    }


/*
    @After
    public void after() throws MalformedURLException {
        Session.getInstance().CloseSession();
    }

 */
}
