package testBasic;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class BasicMovil {

    private AppiumDriver driver;

    @Before
    public void before() throws MalformedURLException {
        System.out.println("BEFORE");

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("deviceName", "Edwin A20s");
        capabilities.setCapability("platformVersion", "9");
        capabilities.setCapability("appPackage", "com.google.android.youtube");
        capabilities.setCapability("appActivity", "com.google.android.apps.youtube.app.WatchWhileActivity");
        capabilities.setCapability("platformName", "Android");

        this.driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

        this.driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);

    }


    @Test
    public void miPrueba2(){
        System.out.println("prueba2");
    }
    @After
    public void after(){
        System.out.println("AFTER");
    }
}
